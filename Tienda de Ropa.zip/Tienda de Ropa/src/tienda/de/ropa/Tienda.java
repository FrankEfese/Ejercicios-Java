package tienda.de.ropa;

import java.util.Arrays;
import java.util.Scanner;

public class Tienda {

    Scanner sc = new Scanner(System.in);

    private static Camisa tablaCamisa[] = new Camisa[0];
    private static Pantalon tablaPantalon[] = new Pantalon[0];
    private static Zapato tablaZapato[] = new Zapato[0];
    private static Accesorios tablaAccesorios[] = new Accesorios[0];

    private static int contCamisa = 0;
    private static int contPantalon = 0;
    private static int contZapato = 0;
    private static int contAccesorios = 0;
    private int parametro;

    private Camisa c;
    private Pantalon p;
    private Zapato z;
    private Accesorios ac;

    public Tienda(Camisa c) {
        this.c = c;
    }

    public Tienda(Pantalon p) {
        this.p = p;
    }

    public Tienda(Zapato z) {
        this.z = z;
    }

    public Tienda(Accesorios ac) {
        this.ac = ac;
    }

    public Tienda() {
    }

    public void anadirCamisa(Camisa camisa) {

        tablaCamisa = Arrays.copyOf(tablaCamisa, tablaCamisa.length + 1);
        tablaCamisa[tablaCamisa.length - 1] = camisa;

        contCamisa++;

    }

    public void anadirPantalon(Pantalon pantalon) {

        tablaPantalon = Arrays.copyOf(tablaPantalon, tablaPantalon.length + 1);
        tablaPantalon[tablaPantalon.length - 1] = pantalon;

        contPantalon++;

    }

    public void anadirZapato(Zapato zapato) {

        tablaZapato = Arrays.copyOf(tablaZapato, tablaZapato.length + 1);
        tablaZapato[tablaZapato.length - 1] = zapato;

        contZapato++;

    }

    public void anadirAccesorio(Accesorios accesorio) {

        tablaAccesorios = Arrays.copyOf(tablaAccesorios, tablaAccesorios.length + 1);
        tablaAccesorios[tablaAccesorios.length - 1] = accesorio;

        contAccesorios++;

    }

    public int longitudTablaCamisa() {

        return tablaCamisa.length;
    }

    public int longitudTablaPantalon() {

        return tablaPantalon.length;
    }

    public int longitudTablaZapato() {

        return tablaZapato.length;
    }

    public int longitudTablaAccesorios() {

        return tablaAccesorios.length;
    }

    public void stock(int stock) {

        switch (stock) {

            case 1:
                System.out.println("\nEste es el STOCK disponible de Camisas : ");
                System.out.println("------------------------");
                if (contCamisa == 0) {
                    System.out.println("No hay STOCK de Camisas");
                } else {

                    for (int x = 0; x < tablaCamisa.length; x++) {

                        System.out.println("\nCodigo: " + x + " / " + "Tipo de Cuello: "
                                + tablaCamisa[x].c + " / " + "Talla: " + tablaCamisa[x].l
                                + " / " + "Marca: " + tablaCamisa[x].m + " / " + "Color: "
                                + tablaCamisa[x].color + " / " + "Precio: " + tablaCamisa[x].precio);

                    }

                }
                break;

            case 2:
                System.out.println("\nEste es el STOCK disponible de Pantalones : ");
                System.out.println("------------------------");

                if (contPantalon == 0) {
                    System.out.println("No hay STOCK de Pantalon");
                } else {

                    for (int x = 0; x < tablaPantalon.length; x++) {

                        System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: " + tablaPantalon[x].c
                                + " / " + "Tipo de Composicion: " + tablaPantalon[x].comp + " / " + "Talla: " + tablaPantalon[x].l
                                + " / " + "Marca: " + tablaPantalon[x].m + " / " + "Color: "
                                + tablaPantalon[x].color + " / " + "Precio: " + tablaPantalon[x].precio);

                    }

                }
                break;

            case 3:

                System.out.println("\nEste es el STOCK disponible de Zapatos : ");
                System.out.println("------------------------");
                if (contZapato == 0) {
                    System.out.println("No hay STOCK de Zapatos");
                } else {

                    for (int x = 0; x < tablaZapato.length; x++) {

                        System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: " + tablaZapato[x].sue
                                + " / " + "Tipo de Cierre: " + tablaZapato[x].cie + " / "
                                + "Marca: " + tablaZapato[x].m + " / " + "Color: " + tablaZapato[x].color
                                + " / " + "Numero: " + tablaZapato[x].numero + " / " + "Precio: " + tablaZapato[x].precio);

                    }

                }
                break;

            case 4:

                System.out.println("\nEste es el STOCK disponible de Accesorios : ");
                System.out.println("------------------------");
                if (contAccesorios == 0) {
                    System.out.println("No hay STOCK de Accesorios");
                } else {

                    for (int x = 0; x < tablaAccesorios.length; x++) {

                        System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: " + tablaAccesorios[x].ac
                                + " / " + "Tipo de Material: " + tablaAccesorios[x].mat + " / " + "Talla: " + tablaAccesorios[x].l
                                + " / " + "Marca: " + tablaAccesorios[x].m + " / " + "Color: "
                                + tablaAccesorios[x].color + " / " + "Precio: " + tablaAccesorios[x].precio);

                    }

                }
                break;

        }

    }

    public void eliminarPrenda() {

        System.out.println("\nQue Prenda quieres dar de baja ? ");
        System.out.println("------------------------");

        do {

            System.out.println("\nPara eliminar una Camisa (Pulsar 1)");
            System.out.println("Para eliminar un Pantalon (Pulsar 2)");
            System.out.println("Para eliminar unos Zapatos (Pulsar 3)");
            System.out.println("Para eliminar un Accesorio (Pulsar 4)");
            System.out.println("Para terminar (PULSE OTRO NUMERO)");

            parametro = sc.nextInt();

            switch (parametro) {

                case 1:

                    if (contCamisa == 0) {
                        System.out.println("\nNo hay STOCK de Camisas");
                    } else {

                        for (int x = 0; x < tablaCamisa.length; x++) {

                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Cuello: "
                                    + tablaCamisa[x].c + " / " + "Talla: " + tablaCamisa[x].l
                                    + " / " + "Marca: " + tablaCamisa[x].m + " / " + "Color: "
                                    + tablaCamisa[x].color + " / " + "Precio: " + tablaCamisa[x].precio);

                        }

                        System.out.println("\nIntroduce el codigo de la Camisa que deseas dar de Baja : ");
                        int codigo = sc.nextInt();

                        if (codigo >= tablaCamisa.length || codigo < 0) {
                            System.out.println("\nTe has equivocado de Codigo.");
                        } else {

                            tablaCamisa[codigo] = tablaCamisa[tablaCamisa.length - 1];
                            tablaCamisa = Arrays.copyOf(tablaCamisa, tablaCamisa.length - 1);
                            contCamisa--;

                            System.out.println("\nSe ha eliminado correctamente.");

                        }

                    }
                    break;

                case 2:

                    if (contPantalon == 0) {
                        System.out.println("\nNo hay STOCK de Pantalones");
                    } else {

                        for (int x = 0; x < tablaPantalon.length; x++) {

                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: " + tablaPantalon[x].c
                                    + " / " + "Tipo de Composicion: " + tablaPantalon[x].comp + " / " + "Talla: " + tablaPantalon[x].l
                                    + " / " + "Marca: " + tablaPantalon[x].m + " / "
                                    + "Color: " + tablaPantalon[x].color + " / " + "Precio: " + tablaPantalon[x].precio);

                        }

                        System.out.println("\nIntroduce el codigo del Pantalon que deseas dar de Baja : ");
                        int codigo = sc.nextInt();

                        if (codigo >= tablaPantalon.length || codigo < 0) {
                            System.out.println("\nTe has equivocado de Codigo.");
                        } else {

                            tablaPantalon[codigo] = tablaPantalon[tablaPantalon.length - 1];
                            tablaPantalon = Arrays.copyOf(tablaPantalon, tablaPantalon.length - 1);
                            contPantalon--;
                            System.out.println("\nSe ha eliminado correctamente.");

                        }

                    }
                    break;

                case 3:

                    if (contZapato == 0) {
                        System.out.println("\nNo hay STOCK de Zapatos");
                    } else {

                        for (int x = 0; x < tablaZapato.length; x++) {

                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                    + tablaZapato[x].sue + " / " + "Tipo de Cierre: " + tablaZapato[x].cie + " / "
                                    + "Marca: " + tablaZapato[x].m + " / " + "Color: "
                                    + tablaZapato[x].color + " / " + "Numero: " + tablaZapato[x].numero + " / " + "Precio: " + tablaZapato[x].precio);

                        }

                        System.out.println("\nIntroduce el codigo del Zapato que deseas dar de Baja : ");
                        int codigo = sc.nextInt();

                        if (codigo >= tablaZapato.length || codigo < 0) {
                            System.out.println("\nTe has equivocado de Codigo.");
                        } else {

                            tablaZapato[codigo] = tablaZapato[tablaZapato.length - 1];
                            tablaZapato = Arrays.copyOf(tablaZapato, tablaZapato.length - 1);
                            contZapato--;
                            System.out.println("\nSe ha eliminado correctamente.");

                        }

                    }
                    break;

                case 4:

                    if (contAccesorios == 0) {
                        System.out.println("\nNo hay STOCK de Accesorios");
                    } else {

                        for (int x = 0; x < tablaAccesorios.length; x++) {

                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                    + tablaAccesorios[x].ac + " / " + "Tipo de Material: " + tablaAccesorios[x].mat + " / " + "Talla: " + tablaAccesorios[x].l
                                    + " / " + "Marca: " + tablaAccesorios[x].m + " / "
                                    + "Color: " + tablaAccesorios[x].color + " / " + "Precio: " + tablaAccesorios[x].precio);

                        }

                        System.out.println("\nIntroduce el codigo del Accesorios que deseas dar de Baja : ");
                        int codigo = sc.nextInt();

                        if (codigo >= tablaAccesorios.length || codigo < 0) {
                            System.out.println("\nTe has equivocado de Codigo.");
                        } else {

                            tablaAccesorios[codigo] = tablaAccesorios[tablaAccesorios.length - 1];
                            tablaAccesorios = Arrays.copyOf(tablaAccesorios, tablaAccesorios.length - 1);
                            contAccesorios--;
                            System.out.println("\nSe ha eliminado correctamente.");

                        }

                    }
                    break;

            }
        } while (parametro > 0 && parametro < 5);

    }

    public static Camisa[] getTablaCamisa() {
        return tablaCamisa;
    }

    public static Pantalon[] getTablaPantalon() {
        return tablaPantalon;
    }

    public static Zapato[] getTablaZapato() {
        return tablaZapato;
    }

    public static Accesorios[] getTablaAccesorios() {
        return tablaAccesorios;
    }

    public void borrarCamisa(int codigo) {

        tablaCamisa[codigo] = tablaCamisa[tablaCamisa.length - 1];
        tablaCamisa = Arrays.copyOf(tablaCamisa, tablaCamisa.length - 1);
        contCamisa--;

    }

    public void borrarPantalon(int codigo) {

        tablaPantalon[codigo] = tablaPantalon[tablaPantalon.length - 1];
        tablaPantalon = Arrays.copyOf(tablaPantalon, tablaPantalon.length - 1);
        contPantalon--;

    }

    public void borrarZapato(int codigo) {

        tablaZapato[codigo] = tablaZapato[tablaZapato.length - 1];
        tablaZapato = Arrays.copyOf(tablaZapato, tablaZapato.length - 1);
        contZapato--;

    }

    public void borrarAccesorio(int codigo) {

        tablaAccesorios[codigo] = tablaAccesorios[tablaAccesorios.length - 1];
        tablaAccesorios = Arrays.copyOf(tablaAccesorios, tablaAccesorios.length - 1);
        contAccesorios--;

    }

}
