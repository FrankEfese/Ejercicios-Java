package tienda.de.ropa;

public class Prenda {

    protected enum Talla {
        S, X, L, XL
    };

    protected enum Marca {
        adidas, nike, zara, shein, HyM
    };
    protected String color;
    protected double precio;
    protected Talla l;
    protected Marca m;

    public Prenda(String color, double precio, Talla l, Marca m) {
        this.color = color;
        this.precio = precio;
        this.l = l;
        this.m = m;
    }

    public Prenda(String color, double precio, Marca m) {
        this.color = color;
        this.precio = precio;
        this.m = m;
    }

    public Prenda() {
    }

}
