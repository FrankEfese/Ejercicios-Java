package tienda.de.ropa;

import java.util.Scanner;

public class Zapato extends Prenda {

    Scanner sc = new Scanner(System.in);

    double numero;

    public enum Suela {
        GOMA, CUERO, CORCHO, TACOS
    };

    public enum Cierre {
        CORDONES, VELCRO
    };

    Suela sue;
    Cierre cie;
    private int cont = 0;
    private int eleccion;
    private Tienda t = new Tienda();

    public Zapato(double numero, Suela sue, Cierre cie, String color, double precio, Marca m) {
        super(color, precio, m);
        this.numero = numero;
        this.sue = sue;
        this.cie = cie;
    }

    public Zapato() {
    }

    public void mostrarZapatoEspe() {

        Zapato tabla[] = t.getTablaZapato();

        if (tabla.length == 0) {
            System.out.println("\nNo hay STOCK de Zapatos.");
        } else {
            System.out.println("\nEscoge la caracteristica que quieres buscar : ");
            System.out.println("------------------------");

            do {

                System.out.println("Por Marca (Pulsar 1)");
                System.out.println("Por rango de Precio (Pulsar 2)");
                System.out.println("Por tipo de Suela (Pulsar 3)");
                System.out.println("Por tipo de Cierre (Pulsar 4)");
                System.out.println("Por numero de Pie (Pulsar 5)");
                eleccion = sc.nextInt();

                switch (eleccion) {

                    case 1:

                        System.out.println("\nAhora introduce la Marca que deseas buscar : ");
                        System.out.println("Para Adidas (Pulsar 1)");
                        System.out.println("Para Nike (Pulsar 2)");
                        System.out.println("Para Zara (Pulsar 3)");
                        System.out.println("Para Shein (Pulsar 4)");
                        System.out.println("Para HyM (Pulsar 5)");
                        int marca = sc.nextInt();

                        switch (marca) {

                            case 1:

                                cont = 0;

                                for (Zapato p : tabla) {
                                    if (p.m == Marca.adidas) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Zapatos con esta Marca.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.adidas) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                                    + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                                    + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 2:

                                cont = 0;

                                for (Zapato p : tabla) {
                                    if (p.m == Marca.nike) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Zapatos con esta Marca.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.nike) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                                    + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                                    + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 3:

                                cont = 0;
                                for (Zapato p : tabla) {
                                    if (p.m == Marca.zara) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Zapatos con esta Marca.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.zara) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                                    + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                                    + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 4:

                                cont = 0;
                                for (Zapato p : tabla) {
                                    if (p.m == Marca.shein) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Zapatos con esta Marca.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.shein) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                                    + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                                    + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 5:

                                cont = 0;
                                for (Zapato p : tabla) {
                                    if (p.m == Marca.HyM) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Zapatos con esta Marca.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.HyM) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                                    + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                                    + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            default:
                                System.out.println("\nTe has equivocado de Numero.");
                        }
                        break;

                    case 2:

                        cont = 0;

                        System.out.println("\nIntroduce dos rangos de Precio : ");
                        System.out.println("El primero : ");

                        int precio1 = sc.nextInt();
                        System.out.println("El segundo : ");
                        int precio2 = sc.nextInt();

                        precio1 = Math.min(precio1, precio2);
                        precio2 = Math.max(precio1, precio2);

                        for (Zapato p : tabla) {
                            if (p.precio >= precio1 && p.precio <= precio2) {
                                cont++;
                            }

                        }

                        if (cont == 0) {
                            System.out.println("\nNo hay Zapatos con este rango de Precio.");
                        } else {
                            System.out.println("\nResulatdo de la busqueda : ");
                            System.out.println("------------------------");
                            for (int x = 0; x < tabla.length; x++) {
                                if (tabla[x].precio >= precio1 && tabla[x].precio <= precio2) {

                                    System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                            + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                            + "Marca: " + tabla[x].m + " / " + "Color: "
                                            + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                }
                            }

                        }

                        break;

                    case 3:

                        System.out.println("\nAhora introduce la Suela que deseas buscar : ");
                        System.out.println("Para Goma (Pulsar 1)");
                        System.out.println("Para Cuero (Pulsar 2)");
                        System.out.println("Para Corcho (Pulsar 3)");
                        System.out.println("Para Tacos (Pulsar 4)");

                        int suela = sc.nextInt();

                        switch (suela) {

                            case 1:

                                cont = 0;

                                for (Zapato p : tabla) {
                                    if (p.sue == Suela.GOMA) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Zapatos con esta Suela.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].sue == Suela.GOMA) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                                    + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                                    + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 2:

                                cont = 0;

                                for (Zapato p : tabla) {
                                    if (p.sue == Suela.CUERO) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Zapatos con esta Suela.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].sue == Suela.CUERO) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                                    + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                                    + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 3:

                                cont = 0;

                                for (Zapato p : tabla) {
                                    if (p.sue == Suela.CORCHO) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Zapatos con esta Suela.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].sue == Suela.CORCHO) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                                    + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                                    + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 4:

                                cont = 0;

                                for (Zapato p : tabla) {
                                    if (p.sue == Suela.TACOS) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Zapatos con esta Suela.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].sue == Suela.TACOS) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                                    + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                                    + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            default:
                                System.out.println("\nTe has equivocado de Numero.");

                        }
                        break;

                    case 4:

                        System.out.println("\nIntroduce su tipo de Cierre que deseas buscar : ");
                        System.out.println("Pulsa 1 para Cierre de Cordon");
                        System.out.println("Pulsa 2 para Cierre de Velcro ");
                        int cierre = sc.nextInt();

                        switch (cierre) {

                            case 1:

                                cont = 0;

                                for (Zapato p : tabla) {
                                    if (p.cie == Cierre.CORDONES) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Zapatos con este tipo de Cierre.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].cie == Cierre.CORDONES) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                                    + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                                    + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 2:

                                cont = 0;

                                for (Zapato p : tabla) {
                                    if (p.cie == Cierre.VELCRO) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Zapatos con este tipo de Cierre.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].cie == Cierre.VELCRO) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                                    + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                                    + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            default:
                                System.out.println("\nTe has equivocado de Numero.");
                        }
                        break;

                    case 5:

                        cont = 0;

                        System.out.println("\nIntroduce dos rangos de numero de Pie : ");
                        System.out.println("El primero : ");

                        int precio11 = sc.nextInt();
                        System.out.println("El segundo : ");
                        int precio22 = sc.nextInt();

                        precio11 = Math.min(precio11, precio22);
                        precio22 = Math.max(precio11, precio22);

                        for (Zapato p : tabla) {
                            if (p.numero >= precio11 && p.numero <= precio22) {
                                cont++;
                            }

                        }

                        if (cont == 0) {
                            System.out.println("\nNo hay Zapatos en este rango de numero .");
                        } else {
                            System.out.println("\nResulatdo de la busqueda : ");
                            System.out.println("------------------------");
                            for (int x = 0; x < tabla.length; x++) {
                                if (tabla[x].numero >= precio11 && tabla[x].numero <= precio22) {

                                    System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: "
                                            + tabla[x].sue + " / " + "Tipo de Cierre: " + tabla[x].cie + " / "
                                            + "Marca: " + tabla[x].m + " / " + "Color: "
                                            + tabla[x].color + " / " + "Numero: " + tabla[x].numero + " / " + "Precio: " + tabla[x].precio);

                                }
                            }

                        }

                        break;
                }

                break;

            } while (eleccion > 0 && eleccion < 6);

        }

    }
}
