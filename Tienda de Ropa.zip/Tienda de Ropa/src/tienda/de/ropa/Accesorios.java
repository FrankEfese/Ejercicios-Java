package tienda.de.ropa;

import java.util.Scanner;

public class Accesorios extends Prenda {

    Scanner sc = new Scanner(System.in);

    public enum Acce {
        CORBATA, CINTURON, BUFANDA, GORRO, GUANTES
    };

    public enum Material {
        CUERO, SEDA, ALGODON
    };

    Acce ac;
    Material mat;
    int cont = 0;
    int eleccion;
    Tienda t = new Tienda();

    public Accesorios(Acce ac, Material mat, String color, double precio, Talla l, Marca m) {
        super(color, precio, l, m);
        this.ac = ac;
        this.mat = mat;

    }

    public Accesorios() {
    }

    public void mostrarAccesorioEspe() {

        Accesorios tabla[] = t.getTablaAccesorios();

        if (tabla.length == 0) {
            System.out.println("\nNo hay STOCK de Accesorios.");

        } else {

            System.out.println("\nEscoge la caracteristica que quieres buscar : ");
            System.out.println("------------------------");

            do {

                System.out.println("\nPor Talla (Pulsar 1)");
                System.out.println("Por Marca (Pulsar 2)");
                System.out.println("Por rango de Precio (Pulsar 3)");
                System.out.println("Por tipo de Accesorio (Pulsar 4)");
                System.out.println("Por tipo de Material (Pulsar 5)");
                eleccion = sc.nextInt();

                switch (eleccion) {

                    case 1:

                        System.out.println("\nIntroduce la Talla que deseas buscar : ");
                        System.out.println("Para S (Pulsar 1)");
                        System.out.println("Para X (Pulsar 2)");
                        System.out.println("Para L (Pulsar 3)");
                        System.out.println("Para XL (Pulsar 4)");
                        int talla = sc.nextInt();

                        switch (talla) {

                            case 1:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.l == Talla.S) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con esta Talla.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].l == Talla.S) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                                    + tabla[x].ac + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 2:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.l == Talla.X) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con esta Talla.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].l == Talla.X) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                                    + tabla[x].ac + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 3:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.l == Talla.L) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con esta Talla.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].l == Talla.L) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                                    + tabla[x].ac + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 4:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.l == Talla.XL) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con esta Talla.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].l == Talla.XL) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                                    + tabla[x].ac + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            default:
                                System.out.println("\nTe has equivocado de Numero.");
                                break;

                        }

                        break;

                    case 2:

                        System.out.println("\nAhora introduce la Marca que deseas buscar : ");
                        System.out.println("Para Adidas (Pulsar 1)");
                        System.out.println("Para Nike (Pulsar 2)");
                        System.out.println("Para Zara (Pulsar 3)");
                        System.out.println("Para Shein (Pulsar 4)");
                        System.out.println("Para HyM (Pulsar 5)");
                        int marca = sc.nextInt();

                        switch (marca) {

                            case 1:

                                cont = 0;

                                for (Accesorios p : tabla) {
                                    if (p.m == Marca.adidas) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con esta Marca.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].l == Talla.S) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: " + tabla[x].ac
                                                    + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 2:

                                cont = 0;

                                for (Accesorios p : tabla) {
                                    if (p.m == Marca.nike) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con esta Marca.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.nike) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: " + tabla[x].ac
                                                    + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 3:
                                cont = 0;

                                for (Accesorios p : tabla) {
                                    if (p.m == Marca.zara) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con esta Marca.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.zara) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: " + tabla[x].ac
                                                    + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 4:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.m == Marca.shein) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con esta Marca.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.shein) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: " + tabla[x].ac
                                                    + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 5:
                                cont = 0;

                                for (Accesorios p : tabla) {
                                    if (p.m == Marca.HyM) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con esta Marca.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.HyM) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: " + tabla[x].ac
                                                    + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            default:
                                System.out.println("\nTe has equivocado de Numero.");
                                break;

                        }

                        break;

                    case 3:

                        cont = 0;

                        System.out.println("\nIntroduce dos rangos de Precio : ");
                        System.out.println("El primero : ");

                        int precio1 = sc.nextInt();
                        System.out.println("El segundo : ");
                        int precio2 = sc.nextInt();

                        precio1 = Math.min(precio1, precio2);
                        precio2 = Math.max(precio1, precio2);

                        for (Accesorios p : tabla) {
                            if (p.precio >= precio1 && p.precio <= precio2) {
                                cont++;
                            }

                        }

                        if (cont == 0) {
                            System.out.println("\nNo hay Accesorios con este rango de Precio.");
                        } else {
                            System.out.println("\nResulatdo de la busqueda : ");
                            System.out.println("------------------------");
                            for (int x = 0; x < tabla.length; x++) {
                                if (tabla[x].precio >= precio1 && tabla[x].precio <= precio2) {

                                    System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: " + tabla[x].ac
                                            + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                            + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                            + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                }
                            }

                        }

                        break;

                    case 4:

                        System.out.println("\nAhora introduce el tipo de Accesorio que deseas buscar : ");
                        System.out.println("Para CORBATA (Pulsar 1)");
                        System.out.println("Para CINTURON (Pulsar 2)");
                        System.out.println("Para BUFANDA (Pulsar 3)");
                        System.out.println("Para GORRO (Pulsar 4)");
                        System.out.println("Para GUANTES (Pulsar 5)");
                        int acc = sc.nextInt();

                        switch (acc) {

                            case 1:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.ac == Acce.CORBATA) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay este tipo de Accesorios.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].ac == Acce.CORBATA) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: " + tabla[x].ac
                                                    + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 2:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.ac == Acce.CINTURON) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay este tipo de Accesorios.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].ac == Acce.CINTURON) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                                    + tabla[x].ac + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 3:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.ac == Acce.BUFANDA) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay este tipo de Accesorios.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].ac == Acce.BUFANDA) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                                    + tabla[x].ac + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 4:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.ac == Acce.GORRO) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay este tipo de Accesorios.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].ac == Acce.GORRO) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                                    + tabla[x].ac + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 5:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.ac == Acce.GUANTES) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay este tipo de Accesorios.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].ac == Acce.GUANTES) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                                    + tabla[x].ac + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            default:
                                System.out.println("\nTe has equivocado de Numero.");
                                break;
                        }
                        break;

                    case 5:

                        System.out.println("\nIntroduce el tipo de Material que deseas buscar : ");
                        System.out.println("Para CUERO (Pulsar 1)");
                        System.out.println("Para SEDA (Pulsar 2)");
                        System.out.println("Para ALGODON (Pulsar 3)");

                        int mat = sc.nextInt();

                        switch (mat) {

                            case 1:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.mat == Material.CUERO) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con este tipo de Material.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].mat == Material.CUERO) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                                    + tabla[x].ac + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 2:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.mat == Material.SEDA) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con este tipo de Material.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].mat == Material.SEDA) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                                    + tabla[x].ac + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 3:

                                cont = 0;
                                for (Accesorios p : tabla) {
                                    if (p.mat == Material.ALGODON) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Accesorios con este tipo de Material.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].mat == Material.ALGODON) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: "
                                                    + tabla[x].ac + " / " + "Tipo de Material: " + tabla[x].mat + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            default:
                                System.out.println("\nTe has equivocado de Numero.");
                                break;

                        }

                        break;

                }

                break;

            } while (eleccion > 0 && eleccion < 6);

        }

    }
}
