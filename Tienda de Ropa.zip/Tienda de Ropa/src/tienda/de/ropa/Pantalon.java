package tienda.de.ropa;

import java.util.Scanner;

public class Pantalon extends Prenda {

    Scanner sc = new Scanner(System.in);

    public enum Corte {
        SLIM, REGULAR, CUSTOM
    };

    public enum Composicion {
        ALGODON, LANA, LINO
    };

    Corte c;
    Composicion comp;
    int cont = 0;
    int eleccion;
    Tienda t = new Tienda();

    public Pantalon(Corte c, Composicion comp, String color, double precio, Talla l, Marca m) {
        super(color, precio, l, m);
        this.c = c;
        this.comp = comp;
    }

    public Pantalon() {
    }

    public void mostrarPantalonEspe() {

        Pantalon tabla[] = t.getTablaPantalon();

        if (tabla.length == 0) {
            System.out.println("\nNo hay STOCK de Pantalones.");
        } else {
            System.out.println("\nEscoge la caracteristica que quieres buscar : ");
            System.out.println("------------------------");

            do {
                System.out.println("\nPor Talla (Pulsar 1)");
                System.out.println("Por Marca (Pulsar 2)");
                System.out.println("Por rango de Precio (Pulsar 3)");
                System.out.println("Por tipo de Composicion (Pulsar 4)");
                System.out.println("Por tipo de Corte (Pulsar 5)");
                eleccion = sc.nextInt();

                switch (eleccion) {

                    case 1:

                        System.out.println("\nIntroduce la Talla que deseas buscar : ");
                        System.out.println("Para S (Pulsar 1)");
                        System.out.println("Para X (Pulsar 2)");
                        System.out.println("Para L (Pulsar 3)");
                        System.out.println("Para XL (Pulsar 4)");
                        int talla = sc.nextInt();

                        switch (talla) {

                            case 1:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.l == Talla.S) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con esta Talla.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].l == Talla.S) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 2:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.l == Talla.X) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con esta Talla.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].l == Talla.X) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 3:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.l == Talla.L) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con esta Talla.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].l == Talla.L) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 4:

                                cont = 0;

                                for (Pantalon p : tabla) {
                                    if (p.l == Talla.XL) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con esta Talla.");
                                } else {

                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].l == Talla.XL) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            default:
                                System.out.println("\nTe has equivocado de Numero.");
                                break;

                        }

                        break;

                    case 2:

                        System.out.println("\nAhora introduce la Marca que deseas buscar : ");
                        System.out.println("Para Adidas (Pulsar 1)");
                        System.out.println("Para Nike (Pulsar 2)");
                        System.out.println("Para Zara (Pulsar 3)");
                        System.out.println("Para Shein (Pulsar 4)");
                        System.out.println("Para HyM (Pulsar 5)");
                        int marca = sc.nextInt();

                        switch (marca) {

                            case 1:

                                cont = 0;

                                for (Pantalon p : tabla) {
                                    if (p.m == Marca.adidas) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con esta Marca.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.adidas) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 2:

                                cont = 0;

                                for (Pantalon p : tabla) {
                                    if (p.m == Marca.nike) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con esta Marca.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.nike) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 3:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.m == Marca.zara) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con esta Marca.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.zara) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 4:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.m == Marca.shein) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con esta Marca.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.shein) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 5:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.m == Marca.HyM) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con esta Marca.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].m == Marca.HyM) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            default:
                                System.out.println("\nTe has equivocado de Numero.");
                                break;

                        }

                        break;

                    case 3:

                        cont = 0;

                        System.out.println("\nIntroduce dos rangos de Precio : ");
                        System.out.println("El primero : ");

                        int precio1 = sc.nextInt();
                        System.out.println("El segundo : ");
                        int precio2 = sc.nextInt();

                        precio1 = Math.min(precio1, precio2);
                        precio2 = Math.max(precio1, precio2);

                        for (Pantalon p : tabla) {
                            if (p.precio >= precio1 && p.precio <= precio2) {
                                cont++;
                            }

                        }

                        if (cont == 0) {
                            System.out.println("\nNo hay Pantalones con este rango de Precio.");
                        } else {
                            System.out.println("\nResulatdo de la busqueda : ");
                            System.out.println("------------------------");
                            for (int x = 0; x < tabla.length; x++) {
                                if (tabla[x].precio >= precio1 && tabla[x].precio <= precio2) {

                                    System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                            + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                            + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                            + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                }
                            }

                        }

                        break;

                    case 4:

                        System.out.println("\nIntroduce el tipo de Composicion que deseas buscar : ");
                        System.out.println("Para ALGODON (Pulsar 1)");
                        System.out.println("Para LANA (Pulsar 2)");
                        System.out.println("Para LINO (Pulsar 3)");

                        int compo = sc.nextInt();

                        switch (compo) {

                            case 1:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.comp == Composicion.ALGODON) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con este tipo de Composicion.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].comp == Composicion.ALGODON) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 2:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.comp == Composicion.LANA) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con este tipo de Composicion.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].comp == Composicion.LANA) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 3:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.comp == Composicion.LINO) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con este tipo de Composicion.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].comp == Composicion.LINO) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            default:
                                System.out.println("\nTe has equivocado de Numero.");
                                break;

                        }

                        break;

                    case 5:

                        System.out.println("\nIntroduce el tipo de Corte que deseas buscar : ");
                        System.out.println("Para SLIM (Pulsar 1)");
                        System.out.println("Para REGULAR (Pulsar 2)");
                        System.out.println("Para CUSTOM (Pulsar 3)");

                        int corte = sc.nextInt();

                        switch (corte) {

                            case 1:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.c == Corte.SLIM) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con este tipo de Corte.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].c == Corte.SLIM) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 2:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.c == Corte.REGULAR) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con este tipo de Corte.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].c == Corte.REGULAR) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            case 3:

                                cont = 0;
                                for (Pantalon p : tabla) {
                                    if (p.c == Corte.CUSTOM) {
                                        cont++;
                                    }

                                }

                                if (cont == 0) {
                                    System.out.println("\nNo hay Pantalones con este tipo de Corte.");
                                } else {
                                    System.out.println("\nResulatdo de la busqueda : ");
                                    System.out.println("------------------------");
                                    for (int x = 0; x < tabla.length; x++) {
                                        if (tabla[x].c == Corte.CUSTOM) {

                                            System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: "
                                                    + tabla[x].c + " / " + "Tipo de Composicion: " + tabla[x].comp + " / " + "Talla: " + tabla[x].l
                                                    + " / " + "Marca: " + tabla[x].m + " / " + "Color: "
                                                    + tabla[x].color + " / " + "Precio: " + tabla[x].precio);

                                        }
                                    }

                                }

                                break;

                            default:
                                System.out.println("\nTe has equivocado de Numero.");
                                break;

                        }

                }
                break;

            } while (eleccion > 0 && eleccion < 6);

        }
    }

}
