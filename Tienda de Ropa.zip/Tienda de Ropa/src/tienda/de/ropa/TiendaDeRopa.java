package tienda.de.ropa;

import java.util.Arrays;
import java.util.Scanner;
import tienda.de.ropa.Accesorios.Acce;
import tienda.de.ropa.Accesorios.Material;
import tienda.de.ropa.Camisa.Cuello;
import tienda.de.ropa.Pantalon.Composicion;
import tienda.de.ropa.Pantalon.Corte;
import tienda.de.ropa.Prenda.Marca;
import tienda.de.ropa.Prenda.Talla;
import tienda.de.ropa.Zapato.Cierre;
import tienda.de.ropa.Zapato.Suela;
import java.util.Date;

public class TiendaDeRopa {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Tienda t = new Tienda();
        Venta v2 = new Venta();

        int cont = 0;
        int eleccion;
        int eleccion1;
        int prenda;
        int stock;
        int marca;
        int talla;
        String color;
        double precio;
        int unidades;
        int codigo;

        Cuello c = Cuello.AMERICANO;
        Talla medida = Talla.L;
        Marca m = Marca.HyM;
        Corte cort = Corte.CUSTOM;
        Composicion comp = Composicion.ALGODON;
        Suela sue = Suela.CORCHO;
        Cierre cie = Cierre.CORDONES;
        Acce ac = Acce.BUFANDA;
        Material mat = Material.ALGODON;

        System.out.println("Bienvenido a tu Tienda de Ropa || fashion URBAN || ");

        do {

            System.out.println("\nQue deseas hacer ?");
            System.out.println("------------------------");
            System.out.println("Agregar Prendas (Pulsar 1)");
            System.out.println("Mostrar todo el Stock (Pulsar 2)");
            System.out.println("Para dar de baja una Prenda (Pulsar 3)");
            System.out.println("Buscar una Prenda en especifico (Pulsar 4)");
            System.out.println("Para realizar una Venta (Pulsar 5)");
            System.out.println("Para ver todas las Facturas (Pulsar 6)");
            System.out.println("Para terminar (PULSA OTRO NUMERO)");

            eleccion = sc.nextInt();

            switch (eleccion) {

                case 1:

                    do {

                        System.out.println("\nQue Prenda quieres agregar ? ");
                        System.out.println("------------------------");
                        System.out.println("Para agregar una Camisa (Pulsar 1)");
                        System.out.println("Para agregar un Pantalon (Pulsar 2)");
                        System.out.println("Para agregar unos Zapatos (Pulsar 3)");
                        System.out.println("Para agregar un Accesorio (Pulsar 4)");
                        System.out.println("Para terminar (PULSE OTRO NUMERO)");
                        prenda = sc.nextInt();

                        switch (prenda) {

                            case 1:
                                System.out.println("\nIntroduce las caracteristicas de la Camisa : ");
                                System.out.println("\nIntroduce su tipo de Cuello : ");
                                System.out.println("Pulsa 1 para Cuello Italiano");
                                System.out.println("Pulsa 2 para Cuello Redondo");
                                System.out.println("Pulsa 3 para Cuello Ingles");
                                System.out.println("Pulsa 4 para Cuello Americano");
                                System.out.println("Pulsa 5 para Cuello Frances");

                                int cuello;
                                do {
                                    cuello = sc.nextInt();
                                    switch (cuello) {

                                        case 1 ->
                                            c = Cuello.ITALIANO;

                                        case 2 ->
                                            c = Cuello.REDONDO;

                                        case 3 ->
                                            c = Cuello.INGLES;

                                        case 4 ->
                                            c = Cuello.AMERICANO;

                                        case 5 ->
                                            c = Cuello.FRANCES;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (cuello > 5 || cuello <= 0);

                                System.out.println("\nIntroduce su Color : ");
                                sc.nextLine();
                                color = sc.nextLine();

                                System.out.println("\nIntroduce su Talla : ");
                                System.out.println("Para S (Pulsar 1)");
                                System.out.println("Para X (Pulsar 2)");
                                System.out.println("Para L (Pulsar 3)");
                                System.out.println("Para XL (Pulsar 4)");

                                do {
                                    talla = sc.nextInt();
                                    switch (talla) {

                                        case 1 ->
                                            medida = Talla.S;

                                        case 2 ->
                                            medida = Talla.X;

                                        case 3 ->
                                            medida = Talla.L;

                                        case 4 ->
                                            medida = Talla.XL;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (talla > 4 || talla <= 0);

                                System.out.println("\nAhora introduce su Marca : ");
                                System.out.println("Para Adidas (Pulsar 1)");
                                System.out.println("Para Nike (Pulsar 2)");
                                System.out.println("Para Zara (Pulsar 3)");
                                System.out.println("Para Shein (Pulsar 4)");
                                System.out.println("Para HyM (Pulsar 5)");

                                do {
                                    marca = sc.nextInt();
                                    switch (marca) {

                                        case 1 ->
                                            m = Marca.adidas;

                                        case 2 ->
                                            m = Marca.nike;

                                        case 3 ->
                                            m = Marca.zara;

                                        case 4 ->
                                            m = Marca.shein;

                                        case 5 ->
                                            m = Marca.HyM;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (marca > 5 || marca <= 0);

                                System.out.println("\nAhora introduce su Precio : ");
                                precio = sc.nextDouble();

                                System.out.println("\nCuantas unidades quieres de esta Camisa ? ");
                                unidades = sc.nextInt();
                                Camisa camisa = new Camisa(c, color, precio, medida, m);

                                for (int x = 0; x < unidades; x++) {
                                    t.anadirCamisa(camisa);
                                }

                                System.out.println("\nSe han agregado CORRECTAMENTE.");

                                break;

                            case 2:
                                System.out.println("\nIntroduce las caracteristicas del Pantalon : ");
                                System.out.println("\nIntroduce su tipo de Corte : ");
                                System.out.println("Pulsa 1 para Corte SLIM");
                                System.out.println("Pulsa 2 para Corte REGULAR ");
                                System.out.println("Pulsa 3 para Corte CUSTOM");

                                int corte;
                                do {
                                    corte = sc.nextInt();
                                    switch (corte) {

                                        case 1 ->
                                            cort = Corte.SLIM;

                                        case 2 ->
                                            cort = Corte.REGULAR;

                                        case 3 ->
                                            cort = Corte.CUSTOM;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (corte > 3 || corte <= 0);

                                System.out.println("\nIntroduce su tipo de Composicion : ");
                                System.out.println("Pulsa 1 para Composicion de ALGODON");
                                System.out.println("Pulsa 2 para Composicion de LANA");
                                System.out.println("Pulsa 3 para Composicion de LINO");

                                int compo;
                                do {
                                    compo = sc.nextInt();
                                    switch (compo) {

                                        case 1 ->
                                            comp = Composicion.ALGODON;

                                        case 2 ->
                                            comp = Composicion.LANA;

                                        case 3 ->
                                            comp = Composicion.LINO;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (compo > 3 || compo <= 0);

                                System.out.println("\nIntroduce su Talla : ");
                                System.out.println("Para S (Pulsar 1)");
                                System.out.println("Para X (Pulsar 2)");
                                System.out.println("Para L (Pulsar 3)");
                                System.out.println("Para XL (Pulsar 4)");

                                do {
                                    talla = sc.nextInt();
                                    switch (talla) {

                                        case 1 ->
                                            medida = Talla.S;

                                        case 2 ->
                                            medida = Talla.X;

                                        case 3 ->
                                            medida = Talla.L;

                                        case 4 ->
                                            medida = Talla.XL;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (talla > 4 || talla <= 0);

                                System.out.println("\nAhora introduce su Marca : ");
                                System.out.println("Para Adidas (Pulsar 1)");
                                System.out.println("Para Nike (Pulsar 2)");
                                System.out.println("Para Zara (Pulsar 3)");
                                System.out.println("Para Shein (Pulsar 4)");
                                System.out.println("Para HyM (Pulsar 5)");

                                do {
                                    marca = sc.nextInt();
                                    switch (marca) {

                                        case 1 ->
                                            m = Marca.adidas;

                                        case 2 ->
                                            m = Marca.nike;

                                        case 3 ->
                                            m = Marca.zara;

                                        case 4 ->
                                            m = Marca.shein;

                                        case 5 ->
                                            m = Marca.HyM;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (marca > 5 || marca <= 0);

                                System.out.println("\nIntroduce su Color : ");
                                sc.nextLine();
                                color = sc.nextLine();

                                System.out.println("\nAhora introduce su Precio : ");
                                precio = sc.nextDouble();

                                System.out.println("\nCuantas unidades quieres de este Pantalon ? ");
                                unidades = sc.nextInt();
                                Pantalon p = new Pantalon(cort, comp, color, precio, medida, m);

                                for (int x = 0; x < unidades; x++) {
                                    t.anadirPantalon(p);
                                }

                                System.out.println("\nSe han agregado CORRECTAMENTE.");

                                break;

                            case 3:

                                System.out.println("\nIntroduce las caracteristicas del Zapato : ");
                                System.out.println("\nIntroduce su tipo de Suela : ");
                                System.out.println("Pulsa 1 para Suela de Goma");
                                System.out.println("Pulsa 2 para Suela de Cuero ");
                                System.out.println("Pulsa 3 para Suela de Corcho");
                                System.out.println("Pulsa 4 para Suela de Tacos");

                                int suela;

                                do {
                                    suela = sc.nextInt();
                                    switch (suela) {

                                        case 1 ->
                                            sue = Suela.GOMA;

                                        case 2 ->
                                            sue = Suela.CUERO;

                                        case 3 ->
                                            sue = Suela.CORCHO;

                                        case 4 ->
                                            sue = Suela.TACOS;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (suela > 4 || suela <= 0);

                                System.out.println("\nIntroduce su tipo de Cierre : ");
                                System.out.println("Pulsa 1 para Cierre de Cordon");
                                System.out.println("Pulsa 2 para Cierre de Velcro ");

                                int cierre;

                                do {
                                    cierre = sc.nextInt();
                                    switch (cierre) {

                                        case 1 ->
                                            cie = Cierre.CORDONES;

                                        case 2 ->
                                            cie = Cierre.VELCRO;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (cierre > 2 || cierre <= 0);

                                System.out.println("\nAhora introduce su Marca : ");
                                System.out.println("Para Adidas (Pulsar 1)");
                                System.out.println("Para Nike (Pulsar 2)");
                                System.out.println("Para Zara (Pulsar 3)");
                                System.out.println("Para Shein (Pulsar 4)");
                                System.out.println("Para HyM (Pulsar 5)");

                                do {
                                    marca = sc.nextInt();
                                    switch (marca) {

                                        case 1 ->
                                            m = Marca.adidas;

                                        case 2 ->
                                            m = Marca.nike;

                                        case 3 ->
                                            m = Marca.zara;

                                        case 4 ->
                                            m = Marca.shein;

                                        case 5 ->
                                            m = Marca.HyM;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (marca > 5 || marca <= 0);

                                System.out.println("\nIntroduce el numero de Zapato : ");

                                double numero = sc.nextDouble();

                                System.out.println("\nIntroduce su Color : ");
                                sc.nextLine();
                                color = sc.nextLine();

                                System.out.println("\nAhora introduce su Precio : ");
                                precio = sc.nextDouble();

                                System.out.println("\nCuantas unidades quieres de este Zapato ? ");
                                unidades = sc.nextInt();
                                Zapato z = new Zapato(numero, sue, cie, color, precio, m);

                                for (int x = 0; x < unidades; x++) {
                                    t.anadirZapato(z);
                                }

                                System.out.println("\nSe han agregado CORRECTAMENTE.");

                                break;

                            case 4:

                                System.out.println("\nIntroduce las caracteristicas del Accesorio : ");
                                System.out.println("\nIntroduce su Tipo : ");
                                System.out.println("Pulsa 1 para Corbata");
                                System.out.println("Pulsa 2 para Cinturon ");
                                System.out.println("Pulsa 3 para Bufanda");
                                System.out.println("Pulsa 4 para Gorro");
                                System.out.println("Pulsa 5 para Guantes");
                                int acce;
                                do {
                                    acce = sc.nextInt();
                                    switch (acce) {

                                        case 1 ->
                                            ac = Acce.CORBATA;

                                        case 2 ->
                                            ac = Acce.CINTURON;

                                        case 3 ->
                                            ac = Acce.BUFANDA;

                                        case 4 ->
                                            ac = Acce.GORRO;

                                        case 5 ->
                                            ac = Acce.GUANTES;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (acce > 5 || acce <= 0);

                                System.out.println("\nIntroduce su Material : ");
                                System.out.println("Pulsa 1 para Cuero");
                                System.out.println("Pulsa 2 para Seda ");
                                System.out.println("Pulsa 3 para Algodon");

                                int material;
                                do {
                                    material = sc.nextInt();
                                    switch (material) {

                                        case 1 ->
                                            mat = Material.CUERO;

                                        case 2 ->
                                            mat = Material.SEDA;

                                        case 3 ->
                                            mat = Material.ALGODON;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (material > 3 || material <= 0);

                                System.out.println("\nIntroduce su Talla : ");
                                System.out.println("Para S (Pulsar 1)");
                                System.out.println("Para X (Pulsar 2)");
                                System.out.println("Para L (Pulsar 3)");
                                System.out.println("Para XL (Pulsar 4)");

                                do {
                                    talla = sc.nextInt();
                                    switch (talla) {

                                        case 1 ->
                                            medida = Talla.S;

                                        case 2 ->
                                            medida = Talla.X;

                                        case 3 ->
                                            medida = Talla.L;

                                        case 4 ->
                                            medida = Talla.XL;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (talla > 4 || talla <= 0);

                                System.out.println("\nAhora introduce su Marca : ");
                                System.out.println("Para Adidas (Pulsar 1)");
                                System.out.println("Para Nike (Pulsar 2)");
                                System.out.println("Para Zara (Pulsar 3)");
                                System.out.println("Para Shein (Pulsar 4)");
                                System.out.println("Para HyM (Pulsar 5)");

                                do {
                                    marca = sc.nextInt();
                                    switch (marca) {

                                        case 1 ->
                                            m = Marca.adidas;

                                        case 2 ->
                                            m = Marca.nike;

                                        case 3 ->
                                            m = Marca.zara;

                                        case 4 ->
                                            m = Marca.shein;

                                        case 5 ->
                                            m = Marca.HyM;

                                        default ->
                                            System.out.println("Error.");

                                    }

                                } while (marca > 5 || marca <= 0);

                                System.out.println("\nIntroduce su Color : ");
                                sc.nextLine();
                                color = sc.nextLine();

                                System.out.println("\nAhora introduce su Precio : ");
                                precio = sc.nextDouble();

                                System.out.println("\nCuantas unidades quieres de este Accesorio ? ");
                                unidades = sc.nextInt();
                                Accesorios acceso = new Accesorios(ac, mat, color, precio, medida, m);

                                for (int x = 0; x < unidades; x++) {
                                    t.anadirAccesorio(acceso);
                                }

                                System.out.println("\nSe han agregado CORRECTAMENTE.");

                                break;

                        }

                    } while (prenda > 0 && prenda < 5);

                    break;

                case 2:

                    System.out.println("\nBienvenido al menu de STOCK");
                    System.out.println("------------------------");

                    do {
                        System.out.println("\nPara ver el STOCK de Camisas (Pulsa 1)");
                        System.out.println("Para ver el STOCK de Pantalones (Pulsa 2)");
                        System.out.println("Para ver el STOCK de Zapatos (Pulsa 3)");
                        System.out.println("Para ver el STOCK de Accesorios (Pulsa 4)");
                        System.out.println("Para terminar (PULSA OTRO NUMERO)");
                        stock = sc.nextInt();

                        t.stock(stock);

                    } while (stock > 0 && stock < 5);

                    break;

                case 3:

                    t.eliminarPrenda();

                    break;

                case 4:

                    System.out.println("\nQue Prenda quieres buscar ? ");
                    System.out.println("------------------------");

                    do {

                        Camisa ca = new Camisa();
                        Pantalon p = new Pantalon();
                        Zapato zap = new Zapato();
                        Accesorios acceso = new Accesorios();

                        System.out.println("\nPara buscar una Camisa (Pulsar 1)");
                        System.out.println("Para buscar un Pantalon (Pulsar 2)");
                        System.out.println("Para buscar unos Zapatos (Pulsar 3)");
                        System.out.println("Para buscar un Accesorio (Pulsar 4)");
                        System.out.println("Para terminar (PULSE OTRO NUMERO)");

                        prenda = sc.nextInt();

                        switch (prenda) {

                            case 1:
                                ca.mostrarCamisaEspe();
                                break;

                            case 2:
                                p.mostrarPantalonEspe();
                                break;

                            case 3:
                                zap.mostrarZapatoEspe();
                                break;

                            case 4:
                                acceso.mostrarAccesorioEspe();
                                break;

                        }

                    } while (prenda > 0 && prenda < 5);

                    break;

                case 5:

                    Camisa tablaCam[] = new Camisa[0];
                    Pantalon tablaPan[] = new Pantalon[0];
                    Zapato tablaZa[] = new Zapato[0];
                    Accesorios tablaAcce[] = new Accesorios[0];
                    Camisa tablaCam2[] = t.getTablaCamisa();
                    Pantalon tablaPan2[] = t.getTablaPantalon();
                    Zapato tablaZa2[] = t.getTablaZapato();
                    Accesorios tablaAcce2[] = t.getTablaAccesorios();
                    precio = 0;

                    if (tablaCam2.length == 0 && tablaPan2.length == 0 && tablaZa2.length == 0 && tablaAcce2.length == 0) {
                        System.out.println("\nNo hay STOCK de ninguna Prenda , vuelva otro dia.");
                    } else {

                        System.out.println("\nBienvenido al menu de Venta");
                        System.out.println("Primero ingresa una par de Datos.");
                        System.out.println("\nIntroduce tu Nombre : ");
                        sc.nextLine();
                        String nombre = sc.nextLine();
                        System.out.println("\nIntroduce tu Dni : ");
                        String dni = sc.nextLine();

                        System.out.println("\nEs hora de COMPRAR.");
                        System.out.println("------------------------");

                        do {
                            System.out.println("\nPara agregar Prendas al Carrito (Pulsar 1)");
                            System.out.println("Para quitar Prendas del Carrito (Pulsar 2)");
                            System.out.println("Para Terminar la Venta (PULSA OTRO NUMERO)");
                            eleccion1 = sc.nextInt();

                            switch (eleccion1) {

                                case 1:
                                    System.out.println("\nQue Prenda quieres agregar ? ");
                                    System.out.println("------------------------");
                                    System.out.println("Para agregar una Camisa (Pulsar 1)");
                                    System.out.println("Para agregar un Pantalon (Pulsar 2)");
                                    System.out.println("Para agregar unos Zapatos (Pulsar 3)");
                                    System.out.println("Para agregar un Accesorio (Pulsar 4)");
                                    System.out.println("Para terminar (PULSE OTRO NUMERO)");
                                    prenda = sc.nextInt();

                                    switch (prenda) {

                                        case 1:

                                            if (t.longitudTablaCamisa() == 0) {
                                                System.out.println("\nNo hay STOCK de Camisas.");
                                            } else {

                                                t.stock(prenda);

                                                System.out.println("\nIntroduce el Codigo de la Camisa que quieras agregar al Carrito : ");
                                                codigo = sc.nextInt();

                                                if (codigo >= t.longitudTablaCamisa() || codigo < 0) {
                                                    System.out.println("Te has equivocado de Codigo.");
                                                } else {

                                                    tablaCam = Arrays.copyOf(tablaCam, tablaCam.length + 1);
                                                    tablaCam[tablaCam.length - 1] = tablaCam2[codigo];
                                                    precio += tablaCam2[codigo].precio;

                                                    t.borrarCamisa(codigo);

                                                    System.out.println("\nSe ha agregado al Carrito CORRECTAMENTE.");

                                                }
                                            }

                                            break;

                                        case 2:

                                            if (t.longitudTablaPantalon() == 0) {
                                                System.out.println("\nNo hay STOCK de Pantalones.");
                                            } else {

                                                t.stock(prenda);

                                                System.out.println("\nIntroduce el Codigo del Pantalon que quieras agregar al Carrito : ");
                                                codigo = sc.nextInt();

                                                if (codigo >= t.longitudTablaPantalon() || codigo < 0) {
                                                    System.out.println("Te has equivocado de Codigo.");
                                                } else {

                                                    tablaPan = Arrays.copyOf(tablaPan, tablaPan.length + 1);
                                                    tablaPan[tablaPan.length - 1] = tablaPan2[codigo];
                                                    precio += tablaPan2[codigo].precio;

                                                    t.borrarPantalon(codigo);
                                                    System.out.println("\nSe ha agregado al Carrito CORRECTAMENTE.");

                                                }
                                            }

                                            break;

                                        case 3:

                                            if (t.longitudTablaZapato() == 0) {
                                                System.out.println("\nNo hay STOCK de Zapatos.");
                                            } else {

                                                t.stock(prenda);

                                                System.out.println("\nIntroduce el Codigo del Zapato que quieras agregar al Carrito : ");
                                                codigo = sc.nextInt();

                                                if (codigo >= t.longitudTablaZapato() || codigo < 0) {
                                                    System.out.println("Te has equivocado de Codigo.");
                                                } else {

                                                    tablaZa = Arrays.copyOf(tablaZa, tablaZa.length + 1);
                                                    tablaZa[tablaZa.length - 1] = tablaZa2[codigo];
                                                    precio += tablaZa2[codigo].precio;

                                                    t.borrarZapato(codigo);
                                                    System.out.println("\nSe ha agregado al Carrito CORRECTAMENTE.");

                                                }
                                            }

                                            break;

                                        case 4:

                                            if (t.longitudTablaAccesorios() == 0) {
                                                System.out.println("\nNo hay STOCK de Accesorios.");
                                            } else {

                                                t.stock(prenda);

                                                System.out.println("\nIntroduce el Codigo del Accesorio que quieras agregar al Carrito : ");
                                                codigo = sc.nextInt();

                                                if (codigo >= t.longitudTablaAccesorios() || codigo < 0) {
                                                    System.out.println("Te has equivocado de Codigo.");
                                                } else {

                                                    tablaAcce = Arrays.copyOf(tablaAcce, tablaAcce.length + 1);
                                                    tablaAcce[tablaAcce.length - 1] = tablaAcce2[codigo];
                                                    precio += tablaAcce2[codigo].precio;

                                                    t.borrarAccesorio(codigo);
                                                    System.out.println("\nSe ha agregado al Carrito CORRECTAMENTE.");

                                                }
                                            }

                                            break;

                                    }

                                    break;

                                case 2:

                                    System.out.println("\nSelecciona las prendas que quieras Quitar : ");
                                    System.out.println("------------------------");
                                    System.out.println("Para quitar una Camisa (Pulsar 1)");
                                    System.out.println("Para quitar un Pantalon (Pulsar 2)");
                                    System.out.println("Para quitar unos Zapatos (Pulsar 3)");
                                    System.out.println("Para quitar un Accesorio (Pulsar 4)");
                                    System.out.println("Para terminar (PULSE OTRO NUMERO)");

                                    eleccion = sc.nextInt();

                                    switch (eleccion) {

                                        case 1:

                                            if (tablaCam.length == 0) {

                                                System.out.println("\nNo hay Camisas en el Carrito.");
                                            } else {

                                                for (int x = 0; x < tablaCam.length; x++) {

                                                    System.out.println("\nCodigo: " + x + " / " + "Tipo de Cuello: " + tablaCam[x].c
                                                            + " / " + "Talla: " + tablaCam[x].l
                                                            + " / " + "Marca: " + tablaCam[x].m + " / " + "Color: "
                                                            + tablaCam[x].color + " / " + "Precio: " + tablaCam[x].precio);

                                                }

                                                System.out.println("\nIntroduce el codigo de la Camisa que quieras Quitar.");
                                                codigo = sc.nextInt();

                                                if (codigo >= tablaCam.length || codigo < 0) {
                                                    System.out.println("\nTe has equivocado de Codigo.");
                                                } else {

                                                    t.anadirCamisa(tablaCam[codigo]);
                                                    precio -= tablaCam[codigo].precio;

                                                    tablaCam[codigo] = tablaCam[tablaCam.length - 1];
                                                    tablaCam = Arrays.copyOf(tablaCam, tablaCam.length - 1);
                                                    System.out.println("\nSe ha quitado del Carrito CORRECTAMENTE.");

                                                }

                                            }
                                            break;

                                        case 2:

                                            if (tablaPan.length == 0) {

                                                System.out.println("\nNo hay Pantalones en el Carrito.");
                                            } else {

                                                for (int x = 0; x < tablaPan.length; x++) {

                                                    System.out.println("\nCodigo: " + x + " / " + "Tipo de Corte: " + tablaPan[x].c + " / "
                                                            + "Tipo de Composicion: " + tablaPan[x].comp + " / " + "Talla: " + tablaPan[x].l
                                                            + " / " + "Marca: " + tablaPan[x].m + " / " + "Color: " + tablaPan[x].color
                                                            + " / " + "Precio: " + tablaPan[x].precio);

                                                }

                                                System.out.println("\nIntroduce el codigo del Pantalon que quieras Quitar.");
                                                codigo = sc.nextInt();

                                                if (codigo >= tablaPan.length || codigo < 0) {
                                                    System.out.println("\nTe has equivocado de Codigo.");
                                                } else {
                                                    precio -= tablaPan[codigo].precio;

                                                    t.anadirPantalon(tablaPan[codigo]);

                                                    tablaPan[codigo] = tablaPan[tablaPan.length - 1];
                                                    tablaPan = Arrays.copyOf(tablaPan, tablaPan.length - 1);
                                                    System.out.println("\nSe ha quitado del Carrito CORRECTAMENTE.");

                                                }

                                            }
                                            break;

                                        case 3:

                                            if (tablaZa.length == 0) {

                                                System.out.println("\nNo hay Zapatos en el Carrito.");
                                            } else {

                                                for (int x = 0; x < tablaZa.length; x++) {

                                                    System.out.println("\nCodigo: " + x + " / " + "Tipo de Suela: " + tablaZa[x].sue + " / "
                                                            + "Tipo de Cierre: " + tablaZa[x].cie + " / "
                                                            + "Marca: " + tablaZa[x].m + " / " + "Color: " + tablaZa[x].color + " / "
                                                            + "Numero: " + tablaZa[x].numero + " / " + "Precio: " + tablaZa[x].precio);

                                                }

                                                System.out.println("\nIntroduce el codigo del Zapato que quieras Quitar.");
                                                codigo = sc.nextInt();

                                                if (codigo >= tablaZa.length || codigo < 0) {
                                                    System.out.println("\nTe has equivocado de Codigo.");
                                                } else {

                                                    precio -= tablaZa[codigo].precio;

                                                    t.anadirZapato(tablaZa[codigo]);

                                                    tablaZa[codigo] = tablaZa[tablaZa.length - 1];
                                                    tablaZa = Arrays.copyOf(tablaZa, tablaZa.length - 1);
                                                    System.out.println("\nSe ha quitado del Carrito CORRECTAMENTE.");

                                                }

                                            }
                                            break;

                                        case 4:

                                            if (tablaAcce.length == 0) {

                                                System.out.println("\nNo hay Accesorios en el Carrito.");
                                            } else {

                                                for (int x = 0; x < tablaAcce.length; x++) {

                                                    System.out.println("\nCodigo: " + x + " / " + "Tipo de Accesorio: " + tablaAcce[x].ac + " / "
                                                            + "Tipo de Material: " + tablaAcce[x].mat + " / " + "Talla: " + tablaAcce[x].l
                                                            + " / " + "Marca: " + tablaAcce[x].m + " / " + "Color: " + tablaAcce[x].color + " / "
                                                            + "Precio: " + tablaAcce[x].precio);

                                                }

                                                System.out.println("\nIntroduce el codigo del Accesorio que quieras Quitar.");
                                                codigo = sc.nextInt();

                                                if (codigo >= tablaAcce.length || codigo < 0) {
                                                    System.out.println("\nTe has equivocado de Codigo.");
                                                } else {
                                                    precio -= tablaAcce[codigo].precio;

                                                    t.anadirAccesorio(tablaAcce[codigo]);

                                                    tablaAcce[codigo] = tablaAcce[tablaAcce.length - 1];
                                                    tablaAcce = Arrays.copyOf(tablaAcce, tablaAcce.length - 1);
                                                    System.out.println("\nSe ha quitado del Carrito CORRECTAMENTE.");

                                                }

                                            }
                                            break;

                                    }
                                    break;

                            }

                        } while (eleccion1 > 0 && eleccion1 < 3);

                        Date fecha = new Date();

                        Venta v = new Venta(tablaCam, tablaPan, tablaZa, tablaAcce, fecha, nombre, dni, precio);
                        v.anadirVenta();
                        v.facturaVenta(cont);
                        cont++;

                    }

                    break;

                case 6:

                    if (v2.longitudTablaVenta() == 0) {
                        System.out.println("\nAun no se ha realizado ninguna Venta.");
                    } else {

                        v2.listaFacturas();

                        System.out.println("\nIntroduce el codigo de la Factura que deseas ver : ");
                        codigo = sc.nextInt();
                        if (codigo >= v2.longitudTablaVenta() || codigo < 0) {

                            System.out.println("\nTe has equivocado de codigo.");
                        } else {

                            v2.facturaVenta(codigo);

                        }

                    }

            }

        } while (eleccion > 0 && eleccion < 7);
        
        
        System.out.println("\nGRACIAS POR VENIR !!");

    }
}
