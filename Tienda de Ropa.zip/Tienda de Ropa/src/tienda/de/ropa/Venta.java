package tienda.de.ropa;

import java.util.Arrays;
import java.util.Date;

public class Venta {

    private Camisa tablaC[];
    private Pantalon tablaP[];
    private Zapato tablaZ[];
    private Accesorios tablaA[];
    private static Venta tablaVenta[] = new Venta[0];
    private Date fecha;
    private double total = 0;
    private String nombre;
    private String dni;
    private double precio;

    public Venta(Camisa[] tablaC, Pantalon[] tablaP, Zapato[] tablaZ, Accesorios[] tablaA, Date fecha, String nombre, String dni, double precio) {
        this.tablaC = tablaC;
        this.tablaP = tablaP;
        this.tablaZ = tablaZ;
        this.tablaA = tablaA;
        this.nombre = nombre;
        this.dni = dni;
        this.fecha = fecha;
        this.precio = precio;

    }

    public Venta() {
    }

    public void anadirVenta() {
        Venta v = new Venta(tablaC, tablaP, tablaZ, tablaA, fecha, nombre, dni, precio);
        tablaVenta = Arrays.copyOf(tablaVenta, tablaVenta.length + 1);
        tablaVenta[tablaVenta.length - 1] = v;

    }

    public int longitudTablaVenta() {
        return tablaVenta.length;
    }

    public void facturaVenta(int codigo) {

        if (tablaVenta.length == 0) {
            System.out.println("\nAun no se ha realizado ninguna Venta.");
        } else {

            if (codigo >= tablaVenta.length || codigo < 0) {
                System.out.println("\nTe has equivocado de Codigo.");
            } else {

                System.out.println("\nAsi ha quedado la FACTURA : ");
                System.out.println("----------------------");

                System.out.println("Venta realizada por : " + tablaVenta[codigo].nombre + " / " + tablaVenta[codigo].dni);

                if (tablaVenta[codigo].tablaC.length == 0) {

                } else {

                    System.out.println("\nCAMISETAS : ");
                    System.out.println("------------------");

                    for (int x = 0; x < 1; x++) {
                        for (int j = 0; j < tablaVenta[codigo].tablaC.length; j++) {

                            System.out.println("\nCodigo: " + j + " / " + "Tipo de Cuello: " + tablaVenta[codigo].tablaC[j].c
                                    + " / " + "Talla: " + tablaVenta[codigo].tablaC[j].l
                                    + " / " + "Marca: " + tablaVenta[codigo].tablaC[j].m + " / "
                                    + "Color: " + tablaVenta[codigo].tablaC[j].color + " / " + "Precio: " + tablaVenta[codigo].tablaC[j].precio);

                        }

                    }

                }

                if (tablaVenta[codigo].tablaP.length == 0) {

                } else {

                    System.out.println("\nPANTALONES : ");
                    System.out.println("------------------");

                    for (int x = 0; x < 1; x++) {
                        for (int j = 0; j < tablaVenta[codigo].tablaP.length; j++) {

                            System.out.println("\nCodigo: " + j + " / " + "Tipo de Corte: " + tablaVenta[codigo].tablaP[j].c + " / "
                                    + "Tipo de Composicion: " + tablaVenta[codigo].tablaP[j].comp + " / " + "Talla: " + tablaVenta[codigo].tablaP[j].l
                                    + " / " + "Marca: " + tablaVenta[codigo].tablaP[j].m + " / " + "Color: " + tablaVenta[codigo].tablaP[j].color
                                    + " / " + "Precio: " + tablaVenta[codigo].tablaP[j].precio);

                        }

                    }

                }

                if (tablaVenta[codigo].tablaZ.length == 0) {

                } else {

                    System.out.println("\nZAPATOS : ");
                    System.out.println("------------------");
                    for (int x = 0; x < 1; x++) {
                        for (int j = 0; j < tablaVenta[codigo].tablaZ.length; j++) {

                            System.out.println("\nCodigo: " + j + " / " + "Tipo de Suela: " + tablaVenta[codigo].tablaZ[j].sue + " / "
                                    + "Tipo de Cierre: " + tablaVenta[codigo].tablaZ[j].cie + " / "
                                    + "Marca: " + tablaVenta[codigo].tablaZ[j].m + " / " + "Color: " + tablaVenta[codigo].tablaZ[j].color + " / "
                                    + "Numero: " + tablaVenta[codigo].tablaZ[j].numero + " / " + "Precio: " + tablaVenta[codigo].tablaZ[j].precio);

                        }

                    }

                }

                if (tablaVenta[codigo].tablaA.length == 0) {

                } else {

                    System.out.println("\nACCESORIOS : ");
                    System.out.println("------------------");
                    for (int x = 0; x < 1; x++) {
                        for (int j = 0; j < tablaVenta[codigo].tablaA.length; j++) {

                            System.out.println("\nCodigo: " + j + " / " + "Tipo de Accesorio: " + tablaVenta[codigo].tablaA[j].ac + " / "
                                    + "Tipo de Material: " + tablaVenta[codigo].tablaA[j].mat + " / " + "Talla: " + tablaVenta[codigo].tablaA[j].l
                                    + " / " + "Marca: " + tablaVenta[codigo].tablaA[j].m
                                    + " / " + "Color: " + tablaVenta[codigo].tablaA[j].color + " / " + "Precio: " + tablaVenta[codigo].tablaA[j].precio);

                        }

                    }

                }

                System.out.println("\n----------------------");

                System.out.println("El Coste Total de la Venta : " + tablaVenta[codigo].precio + " EUROS");
                System.out.println("Fecha de la Venta : " + tablaVenta[codigo].fecha);

            }
        }
    }

    public void listaFacturas() {

        System.out.println("\nEsta es las lista de Facturas : ");
        System.out.println("----------------------");
        for (int x = 0; x < tablaVenta.length; x++) {

            System.out.println("Codigo Factura : " + x + " / " + "Nombre: " + tablaVenta[x].nombre + " / " + "DNI: " + tablaVenta[x].dni);

        }

    }
}
